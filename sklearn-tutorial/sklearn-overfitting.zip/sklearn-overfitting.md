

```python
from sklearn.learning_curve import  learning_curve
from sklearn.datasets import  load_digits
from sklearn.svm import  SVC 
import matplotlib.pyplot as plot
import numpy as np

```


```python
digits = load_digits()
X = digits.data
y = digits.target

train_sizes,train_loss,test_loss = learning_curve(SVC(gamma=0.001),X,y,cv=10,
                                                  scoring='mean_squared_error',
                                                 train_sizes=[0.1,0.25,0.5,0.75,1])
train_loss_mean = - np.mean(train_loss,axis=1)
test_loss_mean = - np.mean(test_loss, axis=1)

```


```python
%matplotlib inline

plot.plot(train_sizes, train_loss_mean,'o-',color='r',label="Training")
plot.plot(train_sizes,test_loss_mean,'o-',color='g',label="Cross-validation")

plot.xlabel("Traning example")
plot.ylabel("Loss")
plot.legend(loc="best")
plot.show()
```


![png](output_2_0.png)



```python
#set gamma 0.01 
digits = load_digits()
X = digits.data
y = digits.target

train_sizes,train_loss,test_loss = learning_curve(SVC(gamma=0.01),X,y,cv=10,
                                                  scoring='mean_squared_error',
                                                 train_sizes=[0.1,0.25,0.5,0.75,1])
train_loss_mean = - np.mean(train_loss,axis=1)
test_loss_mean = - np.mean(test_loss, axis=1)

plot.plot(train_sizes, train_loss_mean,'o-',color='r',label="Training")
plot.plot(train_sizes,test_loss_mean,'o-',color='g',label="Cross-validation")

plot.xlabel("Traning example")
plot.ylabel("Loss")
plot.legend(loc="best")


```




    <matplotlib.legend.Legend at 0x1122fbbe0>




![png](output_3_1.png)



```python
#调参

from sklearn.learning_curve import  validation_curve

digits = load_digits()
X = digits.data
y = digits.target

#设置gamma的变动的范围
param_range = np.logspace(-6,-2.3,5)


train_loss,test_loss = validation_curve(SVC(),X,y,
                                        param_name='gamma',param_range=param_range,
                                        cv=10,scoring='mean_squared_error',
                                        )


train_loss_mean = - np.mean(train_loss,axis=1)
test_loss_mean = - np.mean(test_loss, axis=1)

plot.plot(param_range, train_loss_mean,'o-',color='r',label="Training")
plot.plot(param_range,test_loss_mean,'o-',color='g',label="Cross-validation")

plot.xlabel("gamma")
plot.ylabel("Loss")
plot.legend(loc="best")
plot.show()

#交叉验证的值，随着值的增大比train的值越来越大  避免overfitting的值为0.006左右
```


![png](output_4_0.png)



```python

```
