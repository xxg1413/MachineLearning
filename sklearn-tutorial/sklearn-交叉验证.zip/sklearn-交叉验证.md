

```python
from sklearn.datasets import  load_iris
from sklearn.cross_validation import  train_test_split
from sklearn.neighbors import  KNeighborsClassifier

```


```python
iris = load_iris()
X = iris.data
y = iris.target
```


```python
X_train,X_test, y_train,y_test = train_test_split(X,y,random_state=4)
knn = KNeighborsClassifier(n_neighbors=10) #考虑5个邻居
knn.fit(X_train,y_train)
```




    KNeighborsClassifier(algorithm='auto', leaf_size=30, metric='minkowski',
               metric_params=None, n_jobs=1, n_neighbors=10, p=2,
               weights='uniform')




```python
print(knn.score(X_test,y_test))
```

    0.973684210526



```python
#使用交叉验证
from sklearn.cross_validation import  cross_val_score
knn = KNeighborsClassifier(n_neighbors=5)

#分成5组
scores = cross_val_score(knn,X,y,cv=5,scoring='accuracy')
print(scores)

#结果 和 上面的进行对比 
print(scores.mean())
```

    [ 0.96666667  1.          0.93333333  0.96666667  1.        ]
    0.973333333333



```python
#knn中的n_neighbors 取值影响
%matplotlib inline
import  matplotlib.pyplot as plot 

k_range = range(1,31)
k_scores = []

for k  in k_range:
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn,X,y,cv=10,scoring='accuracy') #分类
    k_scores.append(scores.mean())
    
plot.plot(k_range, k_scores)
plot.xlabel("n_neighbors value")
plot.ylabel("Cross-Validated Accuracy")
plot.show()

#发现在12-18的值，score更好
```


![png](output_5_0.png)



```python
#knn中的n_neighbors 取值影响 回归
%matplotlib inline
import  matplotlib.pyplot as plot 

k_range = range(1,31)
k_scores = []

for k  in k_range:
    knn = KNeighborsClassifier(n_neighbors=k)
    loss = -cross_val_score(knn,X,y,cv=10,scoring='mean_squared_error')
    k_scores.append(loss.mean())
    
plot.plot(k_range, k_scores)
plot.xlabel("n_neighbors value")
plot.ylabel("Cross-Validated Accuracy")
plot.show()

#loss 越小  精确度越高
```


![png](output_6_0.png)

